#!/bin/sh 
java -jar cookie-utils.jar $@
